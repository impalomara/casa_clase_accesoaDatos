package ceu.dam.ad.dto.response;

import lombok.Data;

@Data
public class CreacionEnvioDtoResponse {
	private Long id;

	private String codigo;
}
