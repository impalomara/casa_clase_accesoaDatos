package ceu.dam.ad.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import ceu.dam.ad.model.Envio;

@Repository
public interface EnvioRepository  extends JpaRepository<Envio, Long>{
	boolean findByCodigo(String codigo);
}
