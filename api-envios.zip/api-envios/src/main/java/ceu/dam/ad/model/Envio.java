package ceu.dam.ad.model;

import java.math.BigDecimal;
import java.time.LocalDate;

import lombok.Data;

@Data
public final class Envio {

private Long id;

private String codigo;
private LocalDate fechaRegistro;
private BigDecimal peso;
private String estado;
private BigDecimal temperaturaCelsius;

}
