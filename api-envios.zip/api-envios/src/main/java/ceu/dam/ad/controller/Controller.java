package ceu.dam.ad.controller;

import java.math.BigDecimal;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import ceu.dam.ad.dto.request.CreacionEnvioDtoRequest;
import ceu.dam.ad.dto.request.actualisarEnviosDtoRequest;
import ceu.dam.ad.dto.response.CreacionEnvioDtoResponse;
import ceu.dam.ad.dto.response.EnviosDtoResponse;
import ceu.dam.ad.exceptions.EnvioNoEncontradoException;
import ceu.dam.ad.exceptions.EstadoEnvioInvalidoException;
import ceu.dam.ad.exceptions.PoliticaTransporteInvalidaException;
import ceu.dam.ad.model.Envio;
import ceu.dam.ad.repository.EnvioRepository;
import ceu.dam.ad.service.EnviosService;

public class Controller {

	@Autowired
	private EnviosService service;
	private EnvioRepository repo;

	@GetMapping("/envios/RiesgoTermico/{limiteTemperatura}")
	public List<EnviosDtoResponse> detectarEnviosEnRiesgoTermico(@PathVariable Double limiteTemperatura) {

		if (limiteTemperatura == null || limiteTemperatura < -50 || limiteTemperatura > 50) {

			throw new IllegalArgumentException("La temperatura está fuera de los rangos lógicos de control");
		}

		List<Envio> envios = service.detectarEnviosEnRiesgoTermico(limiteTemperatura);

		ModelMapper mapper = new ModelMapper();

		return envios.stream().map(e -> mapper.map(e, EnviosDtoResponse.class)).toList();
	}

	@PutMapping("/envios/estadoReciente")
	public Long actualizarEstadoLoteReciente(@PathVariable actualisarEnviosDtoRequest request)
			throws EnvioNoEncontradoException {
		if (request.getCodigo().isEmpty()) {
			throw new IllegalArgumentException("La lista esta vacia");
		}

		return service.actualizarEstadoLoteReciente(request.getCodigo(), request.getNuevoEstado());
	}
	
	
	@PostMapping("/envios/nuevo")
	public CreacionEnvioDtoResponse registrarNuevoEnvio(@RequestBody CreacionEnvioDtoRequest request) throws PoliticaTransporteInvalidaException, EstadoEnvioInvalidoException {
		
		if (request.getPeso().compareTo(new BigDecimal("1500")) > 0) {
		    throw new PoliticaTransporteInvalidaException("El peso excede la capacidad maxima");
		}
		if(request.getEstado().equals("REGISTRADO") || request.getEstado().equals("EN_ALMACEN")) {
			throw new EstadoEnvioInvalidoException("No los estandos no son coherente");
		}
		ModelMapper mapper = new ModelMapper();
		Envio envio = mapper.map(request, Envio.class);
		service.registrarNuevoEnvio(envio);
		CreacionEnvioDtoResponse response = mapper.map(envio, CreacionEnvioDtoResponse.class);
		return response;
		
	}
	
	@GetMapping("/envios/masPesado")
	public obtenerEnvioPesadoPrioritario() {
		
	}

}
