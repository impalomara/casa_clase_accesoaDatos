package ceu.dam.ad.orm.practicas.basicas.ejercicio1.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

import ceu.dam.ad.orm.practicas.basicas.ejercicio1.model.Serie;

public interface SerieRepository extends JpaRepository<Serie, Long> {
	Serie findByIdSerie(Long id);
	List<Serie> findByDescripcion(String descripcion);
}
