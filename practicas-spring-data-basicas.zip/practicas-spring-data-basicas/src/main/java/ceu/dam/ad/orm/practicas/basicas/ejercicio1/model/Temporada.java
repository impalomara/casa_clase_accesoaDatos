package ceu.dam.ad.orm.practicas.basicas.ejercicio1.model;

import java.util.List;

import org.springframework.data.annotation.Id;

import jakarta.persistence.OneToMany;
import lombok.Data;


public class Temporada {
	@Id
	private Long id;
	private Integer numero;
	@OneToMany
	private List<Episodio> episodios;
}