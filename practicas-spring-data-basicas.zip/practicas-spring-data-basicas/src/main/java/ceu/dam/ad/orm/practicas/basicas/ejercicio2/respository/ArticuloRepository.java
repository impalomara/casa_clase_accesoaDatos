package ceu.dam.ad.orm.practicas.basicas.ejercicio2.respository;

import org.springframework.data.jpa.repository.JpaRepository;

import ceu.dam.ad.orm.practicas.basicas.ejercicio2.model.Articulo;
import ceu.dam.ad.orm.practicas.basicas.ejercicio2.model.Cliente;
import java.util.List;


public interface ArticuloRepository  extends JpaRepository<Articulo, Long>{

	 Articulo findById(Long id);
	 Articulo findByDescripcion(String descripcion);

}
