package ceu.dam.ad.orm.practicas.basicas.ejercicio2.model;

import java.sql.Types;
import java.util.UUID;

import org.hibernate.annotations.JdbcTypeCode;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;

public class PedidoLinea {
	@Id
	@GeneratedValue(strategy = GenerationType.UUID)
	@JdbcTypeCode(Types.VARCHAR)
	private UUID uidLinea;
	private Integer numLinea;
	private Integer cantidad;
	@OneToOne
	private Articulo articulo;

	public UUID getUidLinea() {
		return uidLinea;
	}
	public void setUidLinea(UUID uidLinea) {
		this.uidLinea = uidLinea;
	}
	public Integer getNumLinea() {
		return numLinea;
	}
	public void setNumLinea(Integer numLinea) {
		this.numLinea = numLinea;
	}
	public Integer getCantidad() {
		return cantidad;
	}
	public void setCantidad(Integer cantidad) {
		this.cantidad = cantidad;
	}
	public Articulo getArticulo() {
		return articulo;
	}
	public void setArticulo(Articulo articulo) {
		this.articulo = articulo;
	}
	@Override
	public String toString() {
		return "PedidoLinea [uidLinea=" + uidLinea + ", numLinea=" + numLinea + ", cantidad=" + cantidad + ", articulo="
				+ articulo + "]";
	}

	

	
}
