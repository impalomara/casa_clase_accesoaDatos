package ceu.dam.ad.orm.practicas.basicas.ejercicio1.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ceu.dam.ad.orm.practicas.basicas.ejercicio1.model.Serie;
import ceu.dam.ad.orm.practicas.basicas.ejercicio1.repository.SerieRepository;

@Service

public class SeriesServiceImpl implements SeriesService {
	private SerieRepository repoSerie;

	public SeriesServiceImpl(SerieRepository repoSerie) {
		this.repoSerie = repoSerie;
	}

	@Override
	public Serie crearSerie(Serie serie) throws SeriesServiceException {
		return repoSerie.save(serie);
	}

	@Override
	public Serie consultarSerie(Long idSerie) throws SerieNotFoundException, SeriesServiceException {
		return repoSerie.findById(idSerie).orElseThrow(() -> new SerieNotFoundException());
	}

	@Override
	public List<Serie> buscarSeries(String filtroDescripcion) throws SerieNotFoundException, SeriesServiceException {
		try {
			List<Serie> listaDescripcion = repoSerie.findByDescripcion(filtroDescripcion);
			if (listaDescripcion.isEmpty()) {
				throw new SerieNotFoundException("");
			}
			return listaDescripcion;
		} catch (Exception e) {
			throw new SeriesServiceException();
		}
	}

	@Override
	public void elimnarSerie(Long idSerie) throws SeriesServiceException {
		try {
			repoSerie.deleteById(idSerie);
		} catch (Exception e) {
			throw new SeriesServiceException();
		}
	}

	@Override
	public void actualizarSerie(Serie serie) throws SeriesServiceException {
		repoSerie.save(serie);
		
	}

}
