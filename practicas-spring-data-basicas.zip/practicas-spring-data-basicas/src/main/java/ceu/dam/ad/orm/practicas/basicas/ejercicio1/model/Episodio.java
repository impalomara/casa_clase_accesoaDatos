package ceu.dam.ad.orm.practicas.basicas.ejercicio1.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;
@Entity
public class Episodio {
	@Id
	private Long id;
	private String titulo;

}
