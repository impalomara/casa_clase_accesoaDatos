package ceu.dam.ad.orm.practicas.basicas.ejercicio2.respository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import ceu.dam.ad.orm.practicas.basicas.ejercicio2.model.Cliente;
import ceu.dam.ad.orm.practicas.basicas.ejercicio2.model.Pedido;
import ceu.dam.ad.orm.practicas.basicas.ejercicio2.model.PedidoLinea;

import java.util.List;


public interface PedidoRepository extends JpaRepository<Pedido, UUID>{
	Pedido findByUidPedido(String uidPedido);
	
	List <Pedido> buscarPedidosPorDescripcionArticulo(@Param("descripcion") String descripcion);

	List<Pedido> findByLineasIn(List<PedidoLinea> pedidoLinea);
}
