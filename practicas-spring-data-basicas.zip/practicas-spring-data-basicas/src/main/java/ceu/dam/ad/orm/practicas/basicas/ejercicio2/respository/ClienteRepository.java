package ceu.dam.ad.orm.practicas.basicas.ejercicio2.respository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import ceu.dam.ad.orm.practicas.basicas.ejercicio2.model.Cliente;

public interface ClienteRepository extends JpaRepository<Cliente, String>{
	Cliente findByDni(String dni);
}
