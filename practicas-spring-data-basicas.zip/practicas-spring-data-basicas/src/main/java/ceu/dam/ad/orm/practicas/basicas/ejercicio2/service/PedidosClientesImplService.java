package ceu.dam.ad.orm.practicas.basicas.ejercicio2.service;

import java.util.List;
import java.util.Optional;

import org.hibernate.exception.DataException;

import ceu.dam.ad.orm.practicas.basicas.ejercicio2.model.Articulo;
import ceu.dam.ad.orm.practicas.basicas.ejercicio2.model.Cliente;
import ceu.dam.ad.orm.practicas.basicas.ejercicio2.model.Pedido;
import ceu.dam.ad.orm.practicas.basicas.ejercicio2.model.PedidoLinea;
import ceu.dam.ad.orm.practicas.basicas.ejercicio2.respository.ArticuloRepository;
import ceu.dam.ad.orm.practicas.basicas.ejercicio2.respository.ClienteRepository;
import ceu.dam.ad.orm.practicas.basicas.ejercicio2.respository.PedidoLineaRepository;
import ceu.dam.ad.orm.practicas.basicas.ejercicio2.respository.PedidoRepository;

public class PedidosClientesImplService implements PedidosClientesService {

	private final ClienteRepository repoCliente;
	private final ArticuloRepository repoArticulo;
	private final PedidoRepository repoPedido;
	private final PedidoLineaRepository repoPedidoFinal;

	public PedidosClientesImplService(ClienteRepository repoCliente, ArticuloRepository repoArticulo,
			PedidoRepository repoPedido, PedidoLineaRepository repoPedidoFinal) {
		this.repoCliente = repoCliente;
		this.repoArticulo = repoArticulo;
		this.repoPedido = repoPedido;
		this.repoPedidoFinal = repoPedidoFinal;
	}

	@Override
	public void crearCliente(Cliente cliente) throws PedidosClientesServiceException {
		try {
			cliente.setPedidos(null);
			repoCliente.save(cliente);
		} catch (DataException e) {
			throw new PedidosClientesServiceException(e);
		}
	}

	@Override
	public Pedido crearPedido(Pedido pedido) throws PedidosClientesServiceException {

		return null;
	}

	@Override
	public Articulo crearArticulo(Articulo articulo) throws PedidosClientesServiceException {
		try {
			repoArticulo.save(articulo);
			return articulo;
		} catch (DataException e) {
			throw new PedidosClientesServiceException(e);
		}
	}

	@Override
	public void actualizarCliente(Cliente cliente) throws PedidosClientesServiceException {
		try {
			cliente.setPedidos(null);
			repoCliente.save(cliente);
		} catch (DataException e) {
			throw new PedidosClientesServiceException(e);
		}

	}

	@Override
	public Cliente consultarCliente(String dni) throws NotFoundException, PedidosClientesServiceException {
		try {
			Cliente cliente = repoCliente.findByDni(dni);
			if (cliente == null) {
				throw new NotFoundException("No se encontro el DNI");
			}
			return cliente;
		} catch (DataException e) {
			throw new PedidosClientesServiceException(e);
		}
	}

	@Override
	public Articulo consultarArticulo(Long idArticulo) throws NotFoundException, PedidosClientesServiceException {
		try {
			Articulo articulo = repoArticulo.findById(idArticulo);
			if (articulo == null) {
				throw new NotFoundException("No se encontro el ID");
			}
			return articulo;
		} catch (DataException e) {
			throw new PedidosClientesServiceException(e);
		}
	}

	@Override
	public Pedido consultarPedido(String uuid) throws NotFoundException, PedidosClientesServiceException {
		try {
			Pedido pedido = repoPedido.findByUidPedido(uuid);
			if (pedido == null) {
				throw new NotFoundException("No se encontro el ID");
			}
			return pedido;
		} catch (DataException e) {
			throw new PedidosClientesServiceException(e);
		}
	}

	@Override
	public List<Pedido> consultarPedidosByArticulo(String descripcionArticulo)
			throws PedidosClientesServiceException, NotFoundException {
		try {
			Articulo articulo = repoArticulo.findByDescripcion(descripcionArticulo);

			if (articulo == null) {
				throw new NotFoundException("No se encontro la descripcion");
			}
			List<PedidoLinea> pedidoLinea = repoPedidoFinal.findByArticulo(articulo);
			List<Pedido> pedidos = repoPedido.findByLineasIn(pedidoLinea);
			return pedidos;
		} catch (DataException e) {
			throw new PedidosClientesServiceException(e);
		}
	}

}
