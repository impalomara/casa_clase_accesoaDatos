package ceu.dam.ad.orm.practicas.basicas.ejercicio2.respository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import ceu.dam.ad.orm.practicas.basicas.ejercicio2.model.Articulo;
import ceu.dam.ad.orm.practicas.basicas.ejercicio2.model.PedidoLinea;
import java.util.List;


public interface PedidoLineaRepository extends JpaRepository<PedidoLinea, UUID>{
	List<PedidoLinea> findByArticulo(Articulo articulo);
}
