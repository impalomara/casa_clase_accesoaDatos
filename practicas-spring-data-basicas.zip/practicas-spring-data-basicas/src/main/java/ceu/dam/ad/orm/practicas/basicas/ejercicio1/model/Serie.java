package ceu.dam.ad.orm.practicas.basicas.ejercicio1.model;

import java.util.Date;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

import lombok.Data;

@Entity
@Data
public class Serie {
	@Id
	private Long id;

	private String descripcion;

	private Date estreno;
	@ManyToOne
	private Trailer trailer;
	@OneToMany
	private List<Temporada> temporadas;
}