package ceu.dam.ad.orm.practicas.basicas.ejercicio1.model;


import jakarta.persistence.Id;
import lombok.Data;

@Data
public class Trailer {

	private Long id;
	private Integer duracion;
	
}
